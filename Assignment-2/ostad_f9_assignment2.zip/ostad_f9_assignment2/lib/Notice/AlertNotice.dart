import 'package:flutter/material.dart';

import '../Controller/contact_controller.dart';
// import '../Pages/Page1.dart';
Future<bool?> showDeleteConfirmationDialog(
    BuildContext context, ContactController contactController, int index) async {
  if (index < 0 || index >= contactController.contacts.length) return Future.value(false);

  return showDialog<bool>(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(2)),
        title: const Text("Confirmation"),
        content: Text("Are you sure you want to delete?"),
        actions: [
          IconButton(
            onPressed: () {
              Navigator.of(context).pop(false); // Cancel delete
            },
            icon: Icon(Icons.no_sim_outlined,color: Colors.blue,),
          ),
          IconButton(
            onPressed: () {
              Navigator.of(context).pop(true); // Confirm delete
            },
            icon: Icon(Icons.delete,color: Colors.blue,),
          ),
        ],
      );
    },
  );
}
