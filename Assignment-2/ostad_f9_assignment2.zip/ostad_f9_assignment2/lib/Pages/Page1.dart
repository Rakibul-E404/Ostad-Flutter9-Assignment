import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import '../Controller/contact_controller.dart';
import '../Notice/AlertNotice.dart';


// ContactApp UI
class ContactApp extends StatefulWidget {
  const ContactApp({super.key});

  @override
  _ContactAppState createState() => _ContactAppState();
}

class _ContactAppState extends State<ContactApp> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController numberController = TextEditingController();
  final ContactController contactController = Get.put(ContactController());

  void addContact() {
    String name = nameController.text.trim();
    String number = numberController.text.trim();
    if (name.isNotEmpty && number.isNotEmpty) {
      contactController.addContact(name, number);
      nameController.clear();
      numberController.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color(0XFF667C89),
          title: const Text("Contact List", style: TextStyle(color: Colors.white)),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              TextField(
                // maxLength: 20,
                inputFormatters: [
                  LengthLimitingTextInputFormatter(20),
                ],
                controller: nameController,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Name",
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                // maxLength: 11,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(11),
                ],
                controller: numberController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  hintText: "Number",
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: WidgetStateProperty.all<Color>(const Color(0XFF667C89)),
                    shape: WidgetStateProperty.all<RoundedRectangleBorder>(
                      RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                    ),
                  ),
                  onPressed: () {
                    FocusScope.of(context).unfocus(); // Hide the keyboard
                    addContact(); // Correctly calling the function
                  },
                  child: const Text("Add", style: TextStyle(color: Colors.white)),
                ),
              ),


              const SizedBox(height: 20),
              Expanded(
                child: Obx(() => ListView.separated(
                  itemCount: contactController.contacts.length,
                  itemBuilder: (context, index) {
                    return Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                      child: ListTile(
                        onLongPress: () async {
                          bool? shouldDelete = await showDeleteConfirmationDialog(context, contactController, index);
                          if (shouldDelete == true) {
                            contactController.deleteContact(index);
                          }
                        },
                        leading: const Icon(Icons.person, color: Color(0xff72564D)), // Person icon
                        title: Text(
                          contactController.contacts[index].name,
                          style: TextStyle(color: Colors.red),
                        ),
                        subtitle: Text(contactController.contacts[index].number),
                        trailing: IconButton(
                          icon: const Icon(Icons.call, color: Colors.blue),
                          onPressed: () {},
                        ),
                      ),
                    );
                  },
                  separatorBuilder: (context, index) => Padding(
                    padding: const EdgeInsets.only(left: 4,right: 4),
                    child: const Divider(height: 2.0,),
                  ), // Divider between cards
                )),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
