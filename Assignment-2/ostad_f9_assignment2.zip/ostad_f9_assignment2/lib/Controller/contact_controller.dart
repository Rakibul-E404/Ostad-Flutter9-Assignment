import 'dart:convert';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Contact {
  String name;
  String number;

  Contact({required this.name, required this.number});

  Map<String, dynamic> toJson() => {'name': name, 'number': number};

  factory Contact.fromJson(Map<String, dynamic> json) {
    return Contact(name: json['name'], number: json['number']);
  }
}

class ContactController extends GetxController {
  var contacts = <Contact>[].obs;

  @override
  void onInit() {
    super.onInit();
    loadContacts();
  }

  void addContact(String name, String number) {
    contacts.add(Contact(name: name, number: number));
    saveContacts();
  }

  void deleteContact(int index) {
    if (index >= 0 && index < contacts.length) {
      contacts.removeAt(index);
      saveContacts();
    }
  }

  void saveContacts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String> contactList =
    contacts.map((contact) => jsonEncode(contact.toJson())).toList();
    await prefs.setStringList('contacts', contactList);
  }

  void loadContacts() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    List<String>? contactList = prefs.getStringList('contacts');
    if (contactList != null) {
      contacts.value =
          contactList.map((item) => Contact.fromJson(jsonDecode(item))).toList();
    }
  }
}
