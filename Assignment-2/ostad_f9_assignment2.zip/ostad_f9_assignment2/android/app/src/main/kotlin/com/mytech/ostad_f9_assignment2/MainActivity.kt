package com.mytech.ostad_f9_assignment2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
